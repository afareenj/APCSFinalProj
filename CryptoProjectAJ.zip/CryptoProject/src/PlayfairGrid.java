public class PlayfairGrid {

	static char[][] grid=new char[5][5];
	
	public PlayfairGrid(String key)
	{
		for(int a=0;a<26;a++)
		{
			char c=(char)(a+65);
			if(key.indexOf(c)==-1)
			{
				key=key+c;
			}
		}
		int j=key.indexOf('J');
		String key1=key.substring(0, j);
		String key2=key.substring(j+1);
		key=key1+key2;
		int a=0;
		for(int r=0;r<5;r++)
		{
			for(int c=0;c<5;c++)
			{
				grid[r][c]=key.charAt(a);
				a=a+1;
			}
		}
	}
	public String findOpposite(char a, char b)
	{
		int r1=0;
		int c1=0;
		int r2=0;
		int c2=0;
		for(int r=0;r<5;r++)
		{
			for(int c=0;c<5;c++)
			{
				if(grid[r][c]==a)
				{
					r1=r;
					c1=c;
				}
				else if(grid[r][c]==b)
				{
					r2=r;
					c2=c;
				}
			}
		}
		String opp="";
		if(r1==r2)
		{
			if(c1<c2)
			{
				if(c2<4)
					opp=opp+grid[r1][c1+1]+""+grid[r2][c2+1];
				else
					opp=opp+grid[r1][c1+1]+""+grid[r2][0];
			}
			else
			{
				if(c1<4)
					opp=opp+grid[r1][c1+1]+""+grid[r2][c2+1];
				else
					opp=opp+grid[r1][0]+""+grid[r2][c2+1];
			}
		}
		else if (c1==c2)
		{
			if(r1<r2)
			{
				if(r2<4)
					opp=opp+grid[r1+1][c1]+""+grid[r2+1][c2];
				else
					opp=opp+grid[r1+1][c1]+""+grid[0][c2];
			}
			else
			{
				if(r1<4)
					opp=opp+grid[r1+1][c1]+""+grid[r2+1][c2];
				else
					opp=opp+grid[0][c1]+""+grid[r2+1][c2];
			}
		}
		else 
			opp=opp+grid[r1][c2]+grid[r2][c1];
		return opp;
	}
	public String deFind(char a, char b) //used in decryption
	{
		int r1=0;
		int c1=0;
		int r2=0;
		int c2=0;
		for(int r=0;r<5;r++)
		{
			for(int c=0;c<5;c++)
			{
				if(grid[r][c]==a)
				{
					r1=r;
					c1=c;
				}
				else if(grid[r][c]==b)
				{
					r2=r;
					c2=c;
				}
			}
		}
		String opp="";
		if(r1==r2)
		{
			if(c1<c2)
			{
				if(c1>0)
					opp=opp+grid[r1][c1-1]+""+grid[r2][c2-1];
				else
					opp=opp+grid[r1][4]+""+grid[r2][c2-1];
			}
			else
			{
				if(c2>0)
					opp=opp+grid[r1][c1-1]+""+grid[r2][c2-1];
				else
					opp=opp+grid[r1][c1-1]+""+grid[r2][4];
			}
		}
		else if (c1==c2)
		{
			if(r1<r2)
			{
				if(r1>0)
					opp=opp+grid[r1-1][c1]+""+grid[r2-1][c2];
				else
					opp=opp+grid[4][c1]+""+grid[r2-1][c2];
			}
			else
			{
				if(r2>0)
					opp=opp+grid[r1-1][c1]+""+grid[r2-1][c2];
				else
					opp=opp+grid[r1-1][c1]+""+grid[4][c2];
			}
		}
		else 
			opp=opp+grid[r1][c2]+grid[r2][c1];
		return opp;
	}
}

