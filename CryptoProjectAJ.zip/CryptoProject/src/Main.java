/** COMMENTS **************************************************************/
/*    Your name: Afareen Jaleel
    Class block: H                
    Lab:Project
    Title: Cryptography
    Purpose: Try to replicate different cryptographic methods in a program
*/
import java.io.FileNotFoundException;
import java.io.File;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input=new Scanner (System.in);
		System.out.println("Welcome to Cipher Program");
		System.out.println("When choosing an option, type the corresponding number.");
		System.out.println("When typing words, type in all caps with no spaces.");
		String option="1";
		while(option!="3")
		{
		System.out.println("Choose an option: ");
		System.out.println("1) Encrypt");
		System.out.println("2) Decrypt");
		System.out.println("3) Quit");
		option=input.next();
		if(option.equals("1"))
		{
			System.out.println("Choose a cipher method:");
			System.out.println("1) Caesar");
			System.out.println("2) Vigenere");
			System.out.println("3) Playfair");
			System.out.println("4) Enigma");
			option=input.next();
			System.out.println("Enter message to encrypt:");
			String message=input.next();
			
			if(option.equals("1"))
			{
				System.out.print("Enter key number to shift by: ");
				int n=Integer.parseInt(input.next());
				message=caesar(n, message);
				System.out.println("Encrypted: "+message);
			}
			else if(option.equals("2"))
			{
				System.out.print("Enter key word: ");
				String key=input.next();
				message=vigenere(key, message);
				System.out.println("Encrypted: "+message);
			}
			else if(option.equals("3"))
			{
				System.out.print("Enter key word: ");
				String key=input.next();
				playFair(key, message);
			}
			else if(option.equals("4"))
			{
				System.out.println("Enter initial position (three letter word): ");
				String key=input.next();
				System.out.println("Enter rotor wiring file name: ");
				String filename=input.next();
				EnigmaMachine mac = readRotor(key, filename);
				message=mac.encrypt(message);
				System.out.println("Encrypted: "+message);
			}
			option="1";
		}
		else if(option.equals("2"))
		{
			System.out.println("Choose a decipher method:");
			System.out.println("1) Caesar");
			System.out.println("2) Vigenere");
			System.out.println("3) Playfair");
			System.out.println("4) Enigma");
			option=input.next();
			System.out.println("Enter message to decipher:");
			String message=input.next();
			if(option.equals("1"))
			{
				System.out.print("Enter key number to shift by: ");
				int n=Integer.parseInt(input.next());
				message=caesar(-n, message);
				System.out.println("Decrypted: "+message);
			}
			else if(option.equals("2"))
			{
				System.out.print("Enter key word: ");
				String key=input.next();
				message=deVigenere(key, message);
				System.out.println("Decrypted: "+message);
			}
			else if(option.equals("3"))
			{
				System.out.print("Enter key word: ");
				String key=input.next();
				dePlayfair(key, message);
			}
			else if(option.equals("4"))
			{
				System.out.println("Enter initial position (three letter word): ");
				String key=input.next();
				System.out.println("Enter rotor wiring file name: ");
				String filename=input.next();
				EnigmaMachine mac = readRotor(key, filename);
				message=mac.decrypt(message);
				System.out.println("Decrypted: "+message);
			}
			option="1";
		}
		else
			System.exit(1);
		}
		input.close();
		
	}
	public static String caesar(int n, String message)
	{
			String line="";
			for(int a=0;a<message.length();a++)
			{
				char c=message.charAt(a);
				int ascii=(int)c;
				ascii=ascii-65;
				ascii=(ascii+n)%26;
				if(ascii<0)
					ascii=ascii+26;
				line=line+(char)((ascii)+65);
			}
			return line;
	}
	
	public static String vigenere(String key, String message)
	{
		char[][] table=new char[26][26];
		int a=0;
		for(int r=0;r<26;r++)
		{
			for(int c=0;c<26;c++)
			{
				a=(r+c)%26;
				a=a+65;
				table[r][c]=(char)a;
			}
		}
		a=0;
		String line="";
		for(int b=0;b<message.length();b++)
		{
			char c=key.charAt(a);
			a=a+1;
			if(a>=key.length())
				a=a%(key.length());
			int col=(int)c;
			col=col-65;
			char d=message.charAt(b);
			int row=(int)d;
			row=row-65;
			line=line+""+table[row][col];
		}
		return line;
	}
	public static String deVigenere(String key, String message)
	{
		char[][] table=new char[26][26];
		int a=0;
		for(int r=0;r<26;r++)
		{
			for(int c=0;c<26;c++)
			{
				a=(r+c)%26;
				a=a+65;
				table[r][c]=(char)a;
			}
		}
		a=0;
		String line="";
		for(int b=0;b<message.length();b++)
		{
			char c=key.charAt(a);
			a=a+1;
			if(a>=key.length())
				a=a%(key.length());
			int num=(int)c;
			num=num-65;
			for(int d=0;d<26;d++)
			{
				if(table[num][d]==message.charAt(b))
					line=line+""+(char)(d+65);
			}
		}
		return line;
	}
	public static void playFair(String key, String message)
	/* Explanation of Playfair Cipher:
	 * The key for a playfair cipher should not have repeated letters or both an i and a j (but it can have either)
	 * i/j are combined, and an x is added to end if plaintext has an odd number of chars
	 * second occurrences of double letters are replaced with an x
	 */
	{
		for(int a=0;a<message.length()-1;a++)
		{
			char c=message.charAt(a);
			message=replaceDoubles(message,c);
		}
		if (message.length()%2==1)
			message=message+"X";
		PlayfairGrid grid = new PlayfairGrid(key);
		String line="";
		for(int a=0;a<message.length();a=a+2)
		{
			line=line+grid.findOpposite(message.charAt(a),message.charAt(a+1));
		}
		System.out.println(line);
		
	}
	public static String replaceDoubles(String message, char c)
	{
		int index=message.indexOf(c);
		String m1=message.substring(0, index);
		String m2=message.substring(index);
		m2.replace(c,'X');
		message=m1+m2;
		return message;
	}
	public static void dePlayfair(String key, String message)
	{
		PlayfairGrid grid = new PlayfairGrid(key);
		
		String line="";
		for(int a=0;a<message.length();a=a+2)
		{
			line=line+grid.deFind(message.charAt(a),message.charAt(a+1));
		}
		System.out.println("Decrypted:" + line);
		
	}
	public static EnigmaMachine readRotor(String key, String filename)
	{
		char[] rotor1=new char[26];
		char[] rotor2=new char[26];
		char[] rotor3=new char[26];
		char[] reflector=new char[26];
		File file=new File(filename);
		try{
			Scanner input1 = new Scanner(file);
			List<String> text=new ArrayList<String>();
			while(input1.hasNextLine())
				text.add(input1.nextLine());
			int a=1;
			for(String s: text)
			{
				if(a==1)
				{
					for(int b=0;b<s.length();b++)
					{
						rotor1[b]=s.charAt(b);
					}
					a=2;
				}
				else if(a==2)
				{
					for(int b=0;b<s.length();b++)
					{
						rotor2[b]=s.charAt(b);
					}
					a=3;
				}
				else if(a==3)
				{
					for(int b=0;b<s.length();b++)
					{
						rotor3[b]=s.charAt(b);
					}
				}
				else
				{
	for(int b=0;b<s.length();b++)
					{
						reflector[b]=s.charAt(b);
					}
}
			}
			input1.close();
		EnigmaMachine mac=new EnigmaMachine(key, rotor1, rotor2, rotor3, reflector);
			return mac;
		}
		catch(FileNotFoundException ex)
		{
			System.out.println("Cannot open");
			System.exit(1);
		}
		EnigmaMachine mac=new EnigmaMachine();
		return mac;
	}

}