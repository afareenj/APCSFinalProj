import java.util.ArrayList;
import java.util.List;
public class EnigmaMachine {

	static char[][] rotor1=new char[26][2];
	static char[][] rotor2=new char[26][2];
	static char[][] rotor3=new char[26][2];
	static char[][] reflector=new char[26][2];
	
	public EnigmaMachine()
	{
		List<Integer>numbers1 = new ArrayList<Integer>();
		List<Integer>numbers2 = new ArrayList<Integer>();
		List<Integer>numbers3 = new ArrayList<Integer>();
		List<Integer>numbers4 = new ArrayList<Integer>();
		for(int a=0;a<26;a++)
		{
			numbers1.add(a);
			numbers2.add(a);
			numbers3.add(a);
			numbers4.add(a);
			char b=(char)(65+a);
			rotor1[a][0]=b;
			rotor2[a][0]=b;
			rotor3[a][0]=b;
			reflector[a][0]=b;
		}
		for(int a=0;a<26;a++) //generate random motor wiring
		{
			rotor1[a][1]=(char)(numbers1.remove((int)((25-a)*Math.random()))+65);
			rotor2[a][1]=(char)(numbers2.remove((int)((25-a)*Math.random()))+65);
			rotor3[a][1]=(char)(numbers3.remove((int)((25-a)*Math.random()))+65);
			reflector[a][1]=(char)(numbers4.remove((int)((25-a)*Math.random()))+65);
		}
	}
	public EnigmaMachine(String set, char[] rotors1, char[] rotors2, char[] rotors3, char[] reflectors)
	{
		int r1=(int)(set.charAt(0))-65;
		int r2=(int)(set.charAt(1))-65;
		int r3=(int)(set.charAt(2))-65;
		for(int a=0;a<26;a++)
		{
			char b=(char)(65+a);
			rotor1[a][0]=b;
			rotor2[a][0]=b;
			rotor3[a][0]=b;
			reflector[a][0]=b;
		}
		for(int a=0;a<r1;a++)
			stepUp(rotor1);
		for(int a=0;a<r2;a++)
			stepUp(rotor2);
		for(int a=0;a<r3;a++)
			stepUp(rotor3);
		for(int a=0;a<26;a++)
		{
			rotor1[a][1]=rotors1[a];
			rotor2[a][1]=rotors2[a];
			rotor3[a][1]=rotors3[a];
			reflector[a][1]=reflectors[a];
		}
		
	}
	public String encrypt(String message)
	{
		String line="";
		for(int a=0;a<message.length();a++)
		{
			char c=message.charAt(a);
			c=switchChar(c, rotor3);
			c=switchChar(c, rotor2);
			c=switchChar(c, rotor1);
			c=switchChar(c, reflector);
			c=switchCharInv(c, rotor1);
			c=switchCharInv(c, rotor2);
			c=switchCharInv(c, rotor3);
			line=line+""+c;
		}
		return line;
	}
	public String decrypt(String message)
	{
		String line="";
		for(int a=0;a<message.length();a++)
		{
			char c=message.charAt(a);
			c=switchChar(c, rotor3);
			c=switchChar(c, rotor2);
			c=switchChar(c, rotor1);
			c=switchCharInv(c, reflector);
			c=switchCharInv(c, rotor1);
			c=switchCharInv(c, rotor2);
			c=switchCharInv(c, rotor3);
			line=line+""+c;
		}
		return line;
	}
	private char switchChar(char c, char[][] rotor)
	{
		for(int b=0;b<26;b++)
		{
			if(c==rotor[b][0])
				return rotor[b][1];
		}
		return c;
	}
	private char switchCharInv(char c, char[][] rotor)
	{
		for(int b=0;b<26;b++)
		{
			if(c==rotor[b][1])
				return rotor[b][0];
		}
		return c;
	}
	private void stepUp(char[][] rotor)
	{
		for(int a=0;a<26;a++)
		{
			int n=((int)(rotor[a][0]))-64;
			if(n==26)
				n=0;
			n=n+65;
			rotor[a][0]=(char)n;
		}
	}
	private void stepDown(char[][] rotor)
	{
		for(int a=0;a<26;a++)
		{
			int n=((int)(rotor[a][0]))-66;
			if(n==-1)
				n=25;
			n=n+65;
			rotor[a][0]=(char)n;
		}
	}
	public void printRotors() //returns all rotor wirings
	{
		for(int a=0;a<26;a++)
			System.out.print(rotor1[a][0]);
		System.out.println("");
		System.out.println("Rotor 1");
		for(int a=0;a<26;a++)
			System.out.print(rotor1[a][1]);
		System.out.println("");
		System.out.println("Rotor 2");
		for(int a=0;a<26;a++)
			System.out.print(rotor2[a][1]);
		System.out.println("");
		System.out.println("Rotor 3");
		for(int a=0;a<26;a++)
			System.out.print(rotor3[a][1]);
		System.out.println("");
		for(int a=0;a<26;a++)
			System.out.print(reflector[a][1]);
		System.out.println("");
	}
	
}
